<li class="<?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
    <a href="<?php echo route('categories.index'); ?>"><i class="fa fa-edit"></i><span>Categories</span></a>
</li>

<li class="<?php echo e(Request::is('attributes*') ? 'active' : ''); ?>">
    <a href="<?php echo route('attributes.index'); ?>"><i class="fa fa-edit"></i><span>Attributes</span></a>
</li>

<li class="<?php echo e(Request::is('products*') ? 'active' : ''); ?>">
    <a href="<?php echo route('products.index'); ?>"><i class="fa fa-edit"></i><span>Products</span></a>
</li>

<li class="<?php echo e(Request::is('values*') ? 'active' : ''); ?>">
    <a href="<?php echo route('values.index'); ?>"><i class="fa fa-edit"></i><span>Values</span></a>
</li>

