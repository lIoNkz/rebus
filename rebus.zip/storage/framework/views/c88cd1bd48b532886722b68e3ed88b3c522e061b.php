<table class="table table-responsive" id="values-table">
    <thead>
        <tr>
            <th>Product Id</th>
        <th>Attr Name</th>
        <th>Attr Value</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $value->product_id; ?></td>
            <td><?php echo $value->attr_name; ?></td>
            <td><?php echo $value->attr_value; ?></td>
            <td>

                <div class='btn-group'>
                    <a href="<?php echo route('edit_values', [$value->id, $value->product_id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                </div>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>