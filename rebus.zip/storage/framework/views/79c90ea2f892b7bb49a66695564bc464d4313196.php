<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('code', 'Code:'); ?>

    <?php echo Form::number('code', null, ['class' => 'form-control']); ?>

</div>

<!-- Price Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('price', 'Price:'); ?>

    <?php echo Form::number('price', null, ['class' => 'form-control']); ?>

</div>

<!-- Category Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_id', 'Category Id:'); ?>

    <?php echo Form::select('category_id', $array , null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('products.index'); ?>" class="btn btn-default">Cancel</a>
</div>
