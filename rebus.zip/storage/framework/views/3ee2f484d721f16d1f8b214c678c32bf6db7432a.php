<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1 class="pull-left">Products</h1>
        <h1 class="pull-right">
           <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="<?php echo route('products.create'); ?>">Add New</a>
        </h1>
    </section>
    <div class="content">
        <div class="clearfix"></div>

        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                <?php echo Form::open(['route' => 'values.store']); ?>

                    
                    <input type="hidden" value="<?php echo e($product_id); ?>" name="product_id">
                    <!-- Attribute  Field -->
                    <div class="form-group col-sm-6">
                        <?php echo Form::label('attr_name', 'Характеристика:'); ?>

                        <?php echo Form::select('attr_name', $array , null, ['class' => 'form-control']); ?>

                    </div>

                    <!-- Value  Field -->
                    <div class="form-group col-sm-6">
                        <?php echo Form::label('attr_value', 'Значение:'); ?>

                        <?php echo Form::text('attr_value', null, ['class' => 'form-control']); ?>

                    </div>

                    <!-- Submit Field -->
                    <div class="form-group col-sm-12">
                        <?php echo Form::submit('Сохранить', ['class' => 'btn btn-primary']); ?>

                        <a href="<?php echo route('show_values_of_product', [$product_id]); ?>" class="btn btn-default">Отмена</a>
                    </div>


                    <?php echo Form::close(); ?>

            </div>
        </div>
        <div class="text-center">
        
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>