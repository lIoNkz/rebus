<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Редактирование характеристики товара
        </h1>
    </section>
    <div class="content">
        <?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="box box-primary">

            <div class="box-body">
                <div class="row">
                    <?php echo Form::model($value, ['route' => ['values.update', $value->id], 'method' => 'patch']); ?>


                              

                    <!-- Attr Name Field -->
                    <div class="form-group col-sm-3">
                        <b>Attr Name:</b><br>
                        <p style="font-size: 2em;"><?php echo e($value->attr_name); ?></p>
                    </div>

                    <!-- Attr Value Field -->
                    <div class="form-group col-sm-6">
                        <?php echo Form::label('attr_value', 'Attr Value:'); ?>

                        <?php echo Form::text('attr_value', null, ['class' => 'form-control']); ?>

                    </div>

                    <!-- Submit Field -->
                    <div class="form-group col-sm-12">
                        <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                        <a href="<?php echo route('show_values_of_product', $product_id); ?>" class="btn btn-default">Cancel</a>
                    </div>


                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>