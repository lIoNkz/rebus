<!-- Text Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('text', 'Text:'); ?>

    <?php echo Form::select('text', ['0' => 'Sunday', '1' => 'Monday', '2' => 'Tuesday'], null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('testts.index'); ?>" class="btn btn-default">Cancel</a>
</div>
