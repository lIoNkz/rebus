<table class="table table-responsive" id="products-table">
    <thead>
        <tr>
            <th>Name</th>
        <th>Code</th>
        <th>Price</th>
        <th>Category Id</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $product->name; ?></td>
            <td><?php echo $product->code; ?></td>
            <td><?php echo $product->price; ?></td>
            <td><?php echo $product->category_id; ?></td>
            <td>
                <?php echo Form::open(['route' => ['products.destroy', $product->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('products.show', [$product->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('products.edit', [$product->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <a href="<?php echo route('show_values_of_product', [$product->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-list-alt"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>