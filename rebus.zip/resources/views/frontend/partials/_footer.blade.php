    <!-- Footer
    ============================================= -->
    

<footer id="footer" class="dark">

    <!-- Copyrights
    ============================================= -->
    <div id="copyrights">

        <div class="container clearfix">
            <div style="font-size: 11px; padding-bottom: 5px">
                * Информация на сайте предоставлена исключительно для предварительного ознакомления.
                    Производитель оставляет за собой право на внесение изменений в конструкцию, комплектацию и дизайн приборов.
                    Комплектация и дизайн товара могут также варьироваться в зависимости от модели,
                    страны поставки и предпочтений заказчика.            </div>
            <div class="col_half">
                <div class="col_half bottommargin-sm copyRights">
                    <p>© 2016-2018                        <strong>Rebus</strong> все права защищены.</p>
                </div>

                
                    <div class="col_half col_last tright bottommargin-sm">
                        <div class="clearfix">

                            
                                <a class="social-icon noradius si-borderless si-youtube" href="https://www.youtube.com/" target="_blank"><i class="icon-youtube"></i><i class="icon-youtube"></i></a>
                            
                                <a class="social-icon noradius si-borderless si-facebook" href="https://www.facebook.com/" target="_blank"><i class="icon-facebook"></i><i class="icon-facebook"></i></a>
                            
                                <a class="social-icon noradius si-borderless si-instagram" href="https://www.instagram.com/" target="_blank"><i class="icon-instagram"></i><i class="icon-instagram"></i></a>
                            
                        </div>

                        <div class="clear"></div>

                    </div>

                            </div>


        </div>

    </div><!-- #copyrights end -->

</footer>    <!-- #footer end -->
